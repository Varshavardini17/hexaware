class InvalidAccountException(Exception):
    def __init__(self, message="Invalid account number entered."):
        super().__init__(message)
