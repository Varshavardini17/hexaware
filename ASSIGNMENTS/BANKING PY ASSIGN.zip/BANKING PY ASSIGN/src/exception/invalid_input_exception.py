class InvalidInputException(Exception):
    def __init__(self, message="Invalid input provided. Please try again."):
        super().__init__(message)
