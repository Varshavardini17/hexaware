
from dao.i_customer_service_provider import ICustomerServiceProvider
from entity.account import Account

class CustomerServiceProviderImpl(ICustomerServiceProvider):

    def __init__(self):
        self.accounts = {}

    def get_account_balance(self, account_number: int) -> float:
        account = self.accounts.get(account_number)
        if account:
            return account.get_balance()
        else:
            raise Exception("Account not found.")

    def deposit(self, account_number: int, amount: float) -> float:
        account = self.accounts.get(account_number)
        if account:
            account.deposit(amount)
            return account.get_balance()
        else:
            raise Exception("Account not found.")

    def withdraw(self, account_number: int, amount: float) -> float:
        account = self.accounts.get(account_number)
        if account:
            account.withdraw(amount)
            return account.get_balance()
        else:
            raise Exception("Account not found.")

    def transfer(self, from_account_number: int, to_account_number: int, amount: float) -> None:
        from_account = self.accounts.get(from_account_number)
        to_account = self.accounts.get(to_account_number)
        if from_account and to_account:
            if from_account.get_balance() >= amount or from_account.get_account_type() == "Current":
                from_account.withdraw(amount)
                to_account.deposit(amount)
            else:
                raise Exception("Insufficient funds for transfer.")
        else:
            raise Exception("One or both accounts not found.")

    def get_account_details(self, account_number: int):
        account = self.accounts.get(account_number)
        if account:
            account.print_account_info()
        else:
            raise Exception("Account not found.")
