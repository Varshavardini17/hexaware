from entity.account import Account
from entity.savings_account import SavingsAccount
from entity.current_account import CurrentAccount
from entity.zero_balance_account import ZeroBalanceAccount
from exception.insufficient_fund_exception import InsufficientFundException
from exception.invalid_account_exception import InvalidAccountException
from exception.overdraft_limit_exceeded_exception import OverDraftLimitExceededException

class BankServiceProviderImpl:
    def __init__(self, branch_name, branch_address):
        self.branch_name = branch_name
        self.branch_address = branch_address
        self.accounts = {}  



    def create_account(self, customer, acc_type, balance):
        acc_type = acc_type.strip().capitalize()  

        if acc_type == "Savings":
            account = SavingsAccount(customer, balance)
        elif acc_type == "Current":
            account = CurrentAccount(customer, balance)
        elif acc_type == "Zerobalance":
            account = ZeroBalanceAccount(customer)
        else:
            raise ValueError("Invalid account type.")

            self.accounts[account.get_account_number()] = account  
        return account


    def get_account(self, acc_no):
        account = self.accounts.get(acc_no)
        if not account:
            raise InvalidAccountException()
        return account

    def get_account_balance(self, acc_no):
        return self.get_account(acc_no).account_balance

    def deposit(self, acc_no, amount):
        account = self.get_account(acc_no)
        account.deposit(amount)
        return account.account_balance

    def withdraw(self, acc_no, amount):
        account = self.get_account(acc_no)
        if isinstance(account, CurrentAccount):
            try:
                account.withdraw(amount)
            except OverDraftLimitExceededException as e:
                raise
        else:
            if amount > account.account_balance:
                raise InsufficientFundException()
            account.withdraw(amount)
        return account.account_balance

    def transfer(self, from_acc, to_acc, amount):
        sender = self.get_account(from_acc)
        receiver = self.get_account(to_acc)

        self.withdraw(from_acc, amount)  
        self.deposit(to_acc, amount)
        return True

    def get_account_details(self, acc_no):
        account = self.get_account(acc_no)
        return account

    def list_accounts(self):
        return sorted(self.accounts.values(), key=lambda acc: acc.customer.first_name.lower())
