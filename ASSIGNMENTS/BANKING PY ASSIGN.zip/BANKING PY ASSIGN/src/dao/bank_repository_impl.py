
from util.db_conn_util import DBConnUtil

class BankRepositoryImpl:
    def create_account(self, customer, acc_no, acc_type, balance):
        try:
            conn = DBConnUtil.get_connection()
            cursor = conn.cursor()
            
            # Insert customer
            cursor.execute("""
                INSERT INTO Customers (first_name, last_name, email, phone, address)
                VALUES (?, ?, ?, ?, ?)
            """, (customer.first_name, customer.last_name, customer.email, customer.phone, customer.address))

            cursor.execute("SELECT SCOPE_IDENTITY()")  
            customer_id = cursor.fetchone()[0]

            # Insert account
            cursor.execute("""
                INSERT INTO Accounts (account_number, account_type, balance, interest_rate, overdraft_limit, customer_id)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (acc_no, acc_type, balance, 3.5 if acc_type == "Savings" else None,
                    5000.0 if acc_type == "Current" else None, customer_id))

            conn.commit()
            print(" Account created successfully.")
        except Exception as e:
            print(" Error creating account:", e)
        finally:
            cursor.close()
            conn.close()
