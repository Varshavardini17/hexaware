import re

def task_1_loan_eligibility():
    print("\n Task 1: Loan Eligibility Check")
    credit_score = int(input("Enter your credit score: "))
    income = float(input("Enter your annual income: $"))

    if credit_score > 700 and income >= 50000:
        print(" You are eligible for a loan.")
    else:
        print(" Sorry, you are not eligible for a loan.")


def task_2_atm_simulation():
    print("\n Task 2: ATM Transaction Simulation")
    balance = float(input("Enter your current balance: $"))

    print("Choose an option:")
    print("1. Check Balance")
    print("2. Withdraw")
    print("3. Deposit")

    option = input("Enter option (1/2/3): ")

    if option == '1':
        print(f" Your current balance is: ${balance:.2f}")
    elif option == '2':
        withdraw = float(input("Enter withdrawal amount: $"))
        if withdraw % 100 == 0 or withdraw % 500 == 0:
            if withdraw <= balance:
                balance -= withdraw
                print(f" Withdrawal successful. New balance: ${balance:.2f}")
            else:
                print(" Insufficient balance.")
        else:
            print(" Withdrawal amount must be in multiples of 100 or 500.")
    elif option == '3':
        deposit = float(input("Enter deposit amount: $"))
        balance += deposit
        print(f" Deposit successful. New balance: ${balance:.2f}")
    else:
        print(" Invalid option selected.")


def task_3_compound_interest():
    print("\n Task 3: Compound Interest Calculator")
    n = int(input("How many customers do you want to calculate interest for? "))

    for i in range(n):
        print(f"\nCustomer {i+1}:")
        initial_balance = float(input("Enter initial balance: $"))
        rate = float(input("Enter annual interest rate (%): "))
        years = int(input("Enter number of years: "))

        future_balance = initial_balance * ((1 + rate / 100) ** years)
        print(f" Future Balance after {years} years: ${future_balance:.2f}")


def task_4_balance_checker():
    print("\n Task 4: Account Balance Checker")

    accounts = {
        "101": 1200.50,
        "102": 980.75,
        "103": 5000.00,
        "104": 305.20
    }

    while True:
        acc = input("Enter account number (or type 'exit' to quit): ")
        if acc.lower() == 'exit':
            break
        if acc in accounts:
            print(f" Account Balance: ${accounts[acc]:.2f}")
        else:
            print(" Invalid account number. Please try again.")


def task_5_password_validation():
    print("\n Task 5: Password Validation")
    password = input("Enter a password: ")

    if len(password) < 8:
        print(" Password must be at least 8 characters long.")
    elif not any(char.isupper() for char in password):
        print(" Password must contain at least one uppercase letter.")
    elif not any(char.isdigit() for char in password):
        print(" Password must contain at least one digit.")
    else:
        print(" Password is valid!")


def task_6_transaction_history():
    print("\n Task 6: Transaction History")
    transactions = []
    balance = 0.0

    while True:
        print("\nOptions: deposit, withdraw, exit")
        action = input("Enter transaction type: ").strip().lower()

        if action == "exit":
            break
        elif action == "deposit":
            amount = float(input("Enter deposit amount: $"))
            balance += amount
            transactions.append(f"Deposited ${amount:.2f}")
            print(f" Deposited. Current balance: ${balance:.2f}")
        elif action == "withdraw":
            amount = float(input("Enter withdrawal amount: $"))
            if amount <= balance:
                balance -= amount
                transactions.append(f"Withdrew ${amount:.2f}")
                print(f" Withdrawal successful. Current balance: ${balance:.2f}")
            else:
                print(" Insufficient balance.")
        else:
            print(" Invalid action.")

    print("\n Transaction History:")
    for t in transactions:
        print(f"• {t}")
    print(f" Final Balance: ${balance:.2f}")


# ================= Main Menu ====================
def main():
    while True:
        print("\n Bank Mini Task Menu:")
        print("1. Loan Eligibility")
        print("2. ATM Simulation")
        print("3. Compound Interest")
        print("4. Account Balance Checker")
        print("5. Password Validation")
        print("6. Transaction History")
        print("7. Exit")

        choice = input("Enter your choice (1-7): ")

        if choice == '1':
            task_1_loan_eligibility()
        elif choice == '2':
            task_2_atm_simulation()
        elif choice == '3':
            task_3_compound_interest()
        elif choice == '4':
            task_4_balance_checker()
        elif choice == '5':
            task_5_password_validation()
        elif choice == '6':
            task_6_transaction_history()
        elif choice == '7':
            print(" Thank you")
            break
        else:
            print(" Invalid choice")


if __name__ == "__main__":
    main()
