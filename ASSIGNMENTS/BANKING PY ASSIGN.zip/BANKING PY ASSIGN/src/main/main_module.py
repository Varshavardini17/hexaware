from dao.bank_service_provider_imp import BankServiceProviderImpl
from entity.customer import Customer
from exception.invalid_account_exception import InvalidAccountException



def main():
    bank = BankServiceProviderImpl("HexaBank", "Pondy")

    while True:
        print("\n HexaBank - Main Menu")
        print("1. Create Account")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Transfer")
        print("5. Get Balance")
        print("6. List Accounts")
        print("7. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            first = input("First Name: ")
            last = input("Last Name: ")
            phone = input("Phone: ")
            address = input("Address: ")
            acc_type = input("Account Type (Savings/Current/Zero): ").capitalize()
            balance = float(input("Initial Deposit: "))

            customer = Customer(first, last, phone, address)
            account = bank.create_account(customer, acc_type, balance)
            print("\n Account Created Successfully!")
            account.print_account_info()
            print(f"Note your Account Number: {account.get_account_number()}")

        elif choice == "2":
            try:
                acc_no = int(input("Enter Account Number: "))
                amount = float(input("Enter Deposit Amount: "))
                new_balance = bank.deposit(acc_no, amount)
                print(f" Deposit Successful. New Balance: ₹{new_balance}")
            except ValueError:
                print(" Invalid input. Please enter numbers only.")
            except InvalidAccountException:
                print(" Invalid account number.")

        elif choice == "3":
            acc_no = int(input("Enter Account Number: "))
            amount = float(input("Enter amount to withdraw: "))
            try:
                bank.withdraw(acc_no, amount)
                print(" Withdrawal Successful!")
            except Exception as e:
                print(f" {e}")

        elif choice == "4":
            from_acc = int(input("Enter Sender Account Number: "))
            to_acc = int(input("Enter Receiver Account Number: "))
            amount = float(input("Enter amount to transfer: "))
            try:
                bank.transfer(from_acc, to_acc, amount)
                print(" Transfer Successful!")
            except Exception as e:
                print(f" {e}")

        elif choice == "5":
            acc_no = int(input("Enter Account Number: "))
            try:
                account = bank.get_account(acc_no)
                print(f" Balance: {account.get_balance()}")
            except Exception as e:
                print(f" {e}")

        elif choice == "6":
            accounts = bank.list_accounts()
            if not accounts:
                print(" No accounts found.")
            for acc in accounts:
                acc.print_account_info()
                print("-" * 30)

        elif choice == "7":
            print(" Exiting HexaBank. Goodbye!")
            break

        else:
            print(" Invalid choice. Try again.")


if __name__ == "__main__":
    main()
