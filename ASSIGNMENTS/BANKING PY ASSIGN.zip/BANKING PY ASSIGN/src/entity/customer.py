
import re

class Customer:
    def __init__(self, customer_id=None, first_name="", last_name="", phone="", address=""):
        self.__customer_id = customer_id
        self.__first_name = first_name
        self.__last_name = last_name
        self.set_phone(phone)
        self.__address = address

    def get_customer_id(self):
        return self.__customer_id

    def set_customer_id(self, cid):
        self.__customer_id = cid

    def get_first_name(self):
        return self.__first_name

    def set_first_name(self, fname):
        self.__first_name = fname

    def get_last_name(self):
        return self.__last_name

    def set_last_name(self, lname):
        self.__last_name = lname


    def get_phone(self):
        return self.__phone

    def set_phone(self, phone):
        self.__phone = phone


    def get_address(self):
        return self.__address

    def set_address(self, address):
        self.__address = address

    def print_customer_info(self):
        print(f"Customer ID: {self.__customer_id}")
        print(f"Name: {self.__first_name} {self.__last_name}")
        print(f"Phone: {self.__phone}")
        print(f"Address: {self.__address}")
