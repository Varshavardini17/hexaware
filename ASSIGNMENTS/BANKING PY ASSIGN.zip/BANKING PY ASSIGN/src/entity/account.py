
from entity.customer import Customer

class Account:
    last_acc_no = 1000  

    def __init__(self, account_type="", balance=0.0, customer=None):
        Account.last_acc_no += 1
        self._account_number = Account.last_acc_no
        self._account_type = account_type
        self._balance = balance
        self._customer = customer

    def get_account_number(self):
        return self._account_number

    def get_account_type(self):
        return self._account_type

    def set_account_type(self, acc_type):
        self._account_type = acc_type

    def get_balance(self):
        return self._balance

    def set_balance(self, amount):
        self._balance = amount

    def get_customer(self):
        return self._customer

    def set_customer(self, customer):
        self._customer = customer

    def print_account_info(self):
        print(f"Account Number: {self._account_number}")
        print(f"Account Type: {self._account_type}")
        print(f"Balance: {self._balance}")
        if self._customer:
            self._customer.print_customer_info()

    def deposit(self, amount):
        if amount > 0:
            self._balance += amount
            print(f"Deposited: {amount}. New Balance: {self._balance}")
        else:
            print("Invalid deposit amount.")

    def withdraw(self, amount):
        if amount <= self._balance:
            self._balance -= amount
            print(f"Withdrew: {amount}. New Balance: {self._balance}")
        else:
            print("Insufficient balance.")

    def calculate_interest(self):
        interest_rate = 4.5 / 100
        return self._balance * interest_rate
    def account_number(self):
        return self._account_number
