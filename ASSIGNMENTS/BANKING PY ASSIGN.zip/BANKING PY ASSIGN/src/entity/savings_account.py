
from entity.account import Account

class SavingsAccount(Account):
    def __init__(self, customer, balance):
        if balance < 500:
            raise ValueError("Minimum balance of 500 required for Savings Account.")
        super().__init__("Savings", balance, customer)  

    def calculate_interest(self):
        interest_rate = 4.5 / 100
        interest = self.get_balance() * interest_rate
        print(f"Interest: {interest}")
        return interest
