
from entity.account import Account

class CurrentAccount(Account):
    OVERDRAFT_LIMIT = 10000.0

    def __init__(self, customer, balance):
        super().__init__("Current", balance, customer)  

    def withdraw(self, amount):
        if amount <= self.get_balance() + CurrentAccount.OVERDRAFT_LIMIT:
            self.set_balance(self.get_balance() - amount)
            print(f"Withdrew: {amount}. New Balance: {self.get_balance()}")
        else:
            print(f"Overdraft limit exceeded. Max withdrawable: {self.get_balance() + CurrentAccount.OVERDRAFT_LIMIT}")

    def calculate_interest(self):
        return 0.0
