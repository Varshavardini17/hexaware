from entity.event import Event

class Movie(Event):
    def __init__(self, event_name, event_date, event_time, venue, total_seats, ticket_price, genre, actor, actress):
        super().__init__(event_name, event_date, event_time, venue, total_seats, ticket_price, "Movie")
        self.genre = genre
        self.actor = actor
        self.actress = actress

    def display_event_details(self):
        print(f"Movie: {self.event_name} | Genre: {self.genre} | Actor: {self.actor} | Actress: {self.actress}")
        print(f"Date: {self.event_date} Time: {self.event_time} Venue: {self.venue.venue_name} Available Seats: {self.available_seats}")