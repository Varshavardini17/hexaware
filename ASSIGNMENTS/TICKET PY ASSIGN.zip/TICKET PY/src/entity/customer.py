class Customer:
    def __init__(self, name, email, phone):
        self.name = name
        self.email = email
        self.phone = phone

    def display_customer_details(self):
        print(f"Customer: {self.name}, Email: {self.email}, Phone: {self.phone}")