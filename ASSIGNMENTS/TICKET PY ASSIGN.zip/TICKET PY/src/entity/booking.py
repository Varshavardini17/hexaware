from datetime import datetime

class Booking:
    booking_counter = 1

    def __init__(self, event, customers, num_tickets):
        self.booking_id = Booking.booking_counter
        Booking.booking_counter += 1
        self.event = event
        self.customers = customers
        self.num_tickets = num_tickets
        self.total_cost = event.ticket_price * num_tickets
        self.booking_date = datetime.now()

    def display_booking_details(self):
        print(f"Booking ID: {self.booking_id} | Event: {self.event.event_name} | Tickets: {self.num_tickets} | Cost: {self.total_cost}")
        print("Customers:")
        for c in self.customers:
            c.display_customer_details()
        print(f"Booking Date: {self.booking_date}")