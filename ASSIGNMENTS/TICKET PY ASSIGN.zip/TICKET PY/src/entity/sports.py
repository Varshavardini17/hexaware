from entity.event import Event

class Sports(Event):
    def __init__(self, event_name, event_date, event_time, venue, total_seats, ticket_price, sport_name, teams):
        super().__init__(event_name, event_date, event_time, venue, total_seats, ticket_price, "Sports")
        self.sport_name = sport_name
        self.teams = teams

    def display_event_details(self):
        print(f"Sports Event: {self.event_name} | Game: {self.sport_name} | Teams: {self.teams}")
        print(f"Date: {self.event_date} Time: {self.event_time} Venue: {self.venue.venue_name} Available Seats: {self.available_seats}")