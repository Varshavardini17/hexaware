from entity.event import Event

class Concert(Event):
    def __init__(self, event_name, event_date, event_time, venue, total_seats, ticket_price, artist, type_):
        super().__init__(event_name, event_date, event_time, venue, total_seats, ticket_price, "Concert")
        self.artist = artist
        self.type = type_

    def display_event_details(self):
        print(f"Concert: {self.event_name} | Artist: {self.artist} | Type: {self.type}")
        print(f"Date: {self.event_date} Time: {self.event_time} Venue: {self.venue.venue_name} Available Seats: {self.available_seats}")