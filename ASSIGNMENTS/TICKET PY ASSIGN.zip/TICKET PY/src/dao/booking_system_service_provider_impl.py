from dao.i_booking_system_service_provider import IBookingSystemServiceProvider
from dao.event_service_provider_impl import EventServiceProviderImpl
from entity.booking import Booking
from entity.customer import Customer
from exceptions.EventNotFoundException import EventNotFoundException
from exceptions.InvalidBookingIDException import InvalidBookingIDException
import datetime

class BookingSystemServiceProviderImpl(EventServiceProviderImpl, IBookingSystemServiceProvider):

    def __init__(self):
        super().__init__()
        self.bookings = {}
        self.booking_id_counter = 1

    def calculate_booking_cost(self, num_tickets: int, ticket_price: float) -> float:
        return num_tickets * ticket_price

    def book_tickets(self, event_name: str, num_tickets: int, array_of_customers: list[Customer]):
        found_event = None
        for event in self.events:
            if event.event_name.lower() == event_name.lower():
                found_event = event
                break

        if not found_event:
            raise EventNotFoundException(f"Event '{event_name}' not found.")

        if found_event.available_seats < num_tickets:
            raise Exception("Not enough seats available.")

        total_cost = self.calculate_booking_cost(num_tickets, found_event.ticket_price)
        found_event.book_tickets(num_tickets)

        booking = Booking(self.booking_id_counter, array_of_customers, found_event, num_tickets, total_cost, datetime.datetime.now())
        self.bookings[self.booking_id_counter] = booking
        self.booking_id_counter += 1

        return booking

    def cancel_booking(self, booking_id: int):
        if booking_id not in self.bookings:
            raise InvalidBookingIDException(f"Booking ID {booking_id} not found.")
        booking = self.bookings.pop(booking_id)
        booking.event.cancel_booking(booking.num_tickets)

    def get_booking_details(self, booking_id: int):
        if booking_id not in self.bookings:
            raise InvalidBookingIDException(f"Booking ID {booking_id} not found.")
        return self.bookings[booking_id]
