from dao.i_event_service_provider import IEventServiceProvider
from entity.movie import Movie
from entity.sports import Sports
from entity.concert import Concert
from entity.venue import Venue
from entity.event import Event
from typing import List

class EventServiceProviderImpl(IEventServiceProvider):

    def __init__(self):
        self.events: List[Event] = []

    def create_event(self, event_name: str, date: str, time: str, total_seats: int, ticket_price: float, event_type: str, venue: Venue) -> Event:
        event_type = event_type.lower()
        if event_type == "movie":
            event = Movie(event_name, date, time, venue, total_seats, ticket_price, "Movie",genre,actor,actress)
        elif event_type == "sports":
            event = Sports(event_name, date, time, venue, total_seats, ticket_price, "Sports",team,sport_name)
        elif event_type == "concert":
            event = Concert(event_name, date, time, venue, total_seats, ticket_price, "Concert",type_,artist)
        else:
            raise ValueError("Invalid event type")

        self.events.append(event)
        return event

    def get_event_details(self):
        return self.events

    def get_available_no_of_tickets(self):
        return sum(event.available_seats for event in self.events)
