from dao.booking_system_service_provider_impl import BookingSystemServiceProviderImpl
from entity.venue import Venue
from entity.customer import Customer
from exceptions.EventNotFoundException import EventNotFoundException
from exceptions.InvalidBookingIDException import InvalidBookingIDException

class TicketBookingSystem:

    def __init__(self):
        self.system = BookingSystemServiceProviderImpl()

    def start(self):
        print(" Welcome to the Event Ticket Booking System ")

        commands = {
            "1": "create_event",
            "2": "book_tickets",
            "3": "cancel_tickets",
            "4": "get_available_seats",
            "5": "get_event_details",
            "6": "get_booking_details",
            "7": "exit",
            "create_event": "create_event",
            "book_tickets": "book_tickets",
            "cancel_tickets": "cancel_tickets",
            "get_available_seats": "get_available_seats",
            "get_event_details": "get_event_details",
            "get_booking_details": "get_booking_details",
            "exit": "exit"
        }

        while True:
            try:
                print("\nAvailable commands:")
                print("1. create_event")
                print("2. book_tickets")
                print("3. cancel_tickets")
                print("4. get_available_seats")
                print("5. get_event_details")
                print("6. get_booking_details")
                print("7. exit")
                
                cmd_input = input("Enter command: ").strip().lower()
                command = commands.get(cmd_input)

                if command == "create_event":
                    name = input("Enter event name: ")
                    date = input("Enter event date (YYYY-MM-DD): ")
                    time = input("Enter event time (HH:MM): ")
                    total_seats = int(input("Enter total seats: "))
                    price = float(input("Enter ticket price: "))
                    event_type = input("Enter event type (Movie, Sports, Concert): ")
                    venue_name = input("Enter venue name: ")
                    venue_address = input("Enter venue address: ")
                    venue = Venue(venue_name, venue_address)

                    event = self.system.create_event(name, date, time, total_seats, price, event_type, venue)
                    print(f" Event '{event.event_name}' created successfully!")

                elif command == "book_tickets":
                    name = input("Enter event name to book: ")
                    num = int(input("Enter number of tickets: "))
                    customers = []
                    for i in range(num):
                        print(f"\nCustomer {i + 1} details:")
                        cname = input("Enter name: ")
                        cemail = input("Enter email: ")
                        cphone = input("Enter phone number: ")
                        customer = Customer(cname, cemail, cphone)
                        customers.append(customer)
                    booking = self.system.book_tickets(name, num, customers)
                    print(f" Booking successful! Booking ID: {booking.booking_id}")

                elif command == "cancel_tickets":
                    bid = int(input("Enter booking ID to cancel: "))
                    self.system.cancel_booking(bid)
                    print(f" Booking {bid} cancelled successfully.")

                elif command == "get_available_seats":
                    seats = self.system.get_available_no_of_tickets()
                    print(f" Total available seats: {seats}")

                elif command == "get_event_details":
                    events = self.system.get_event_details()
                    if events:
                        print("📅 Available Events:")
                        for e in events:
                            e.display_event_details()
                    else:
                        print(" No events found.")

                elif command == "get_booking_details":
                    bid = int(input("Enter booking ID: "))
                    booking = self.system.get_booking_details(bid)
                    booking.display_booking_details()

                elif command == "exit":
                    print(" Thank you for using the ticket booking system!")
                    break

                else:
                    print(" Invalid command. Try again.")

            except EventNotFoundException as e:
                print(f" {e}")
            except InvalidBookingIDException as e:
                print(f" {e}")
            except Exception as e:
                print(f" An unexpected error occurred: {e}")
