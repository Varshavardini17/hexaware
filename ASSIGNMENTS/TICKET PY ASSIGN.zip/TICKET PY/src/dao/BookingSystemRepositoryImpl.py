import pyodbc
from typing import List
from .IBookingSystemRepository import IBookingSystemRepository
from .DBConnUtil import DBConnUtil

class BookingSystemRepositoryImpl(IBookingSystemRepository):
    
    def __init__(self):
        self.connection = DBConnUtil.get_connection()

    def create_event(self, event_name: str, date: str, time: str, total_seats: int, ticket_price: float, event_type: str, venue: str):
        cursor = self.connection.cursor()
        query = """
        INSERT INTO Events (event_name, event_date, event_time, total_seats, ticket_price, event_type, venue)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        cursor.execute(query, (event_name, date, time, total_seats, ticket_price, event_type, venue))
        self.connection.commit()

    def get_event_details(self) -> List:
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM Events")
        return cursor.fetchall()

    def get_available_tickets(self, event_id: int) -> int:
        cursor = self.connection.cursor()
        cursor.execute("SELECT available_seats FROM Events WHERE event_id = ?", (event_id,))
        return cursor.fetchone()[0]

    def calculate_booking_cost(self, num_tickets: int, ticket_price: float) -> float:
        return num_tickets * ticket_price

    def book_tickets(self, event_id: int, num_tickets: int, customer_id: int):
        cursor = self.connection.cursor()
        
        # Update available seats
        available_seats = self.get_available_tickets(event_id)
        if available_seats < num_tickets:
            print(" Not enough available seats.")
            return
        
        new_available_seats = available_seats - num_tickets
        cursor.execute("UPDATE Events SET available_seats = ? WHERE event_id = ?", (new_available_seats, event_id))
        
        # Insert booking record
        query = "INSERT INTO Bookings (event_id, customer_id, num_tickets) VALUES (?, ?, ?)"
        cursor.execute(query, (event_id, customer_id, num_tickets))
        self.connection.commit()
        print(" Tickets booked successfully.")

    def cancel_booking(self, booking_id: int):
        cursor = self.connection.cursor()
        cursor.execute("SELECT event_id, num_tickets FROM Bookings WHERE booking_id = ?", (booking_id,))
        booking = cursor.fetchone()
        
        if booking:
            event_id, num_tickets = booking
            
            cursor.execute("SELECT available_seats FROM Events WHERE event_id = ?", (event_id,))
            available_seats = cursor.fetchone()[0]
            new_available_seats = available_seats + num_tickets
            cursor.execute("UPDATE Events SET available_seats = ? WHERE event_id = ?", (new_available_seats, event_id))
            
            # Delete booking record
            cursor.execute("DELETE FROM Bookings WHERE booking_id = ?", (booking_id,))
            self.connection.commit()
            print(" Booking cancelled and seats updated.")
        else:
            print(" Booking not found.")

    def get_booking_details(self, booking_id: int):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM Bookings WHERE booking_id = ?", (booking_id,))
        return cursor.fetchone()
