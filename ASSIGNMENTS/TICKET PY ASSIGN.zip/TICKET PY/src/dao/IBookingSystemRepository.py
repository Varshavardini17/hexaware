from abc import ABC, abstractmethod
from typing import List

class IBookingSystemRepository(ABC):
    
    @abstractmethod
    def create_event(self, event_name: str, date: str, time: str, total_seats: int, ticket_price: float, event_type: str, venue: str):
        pass
    
    @abstractmethod
    def get_event_details(self) -> List:
        pass
    
    @abstractmethod
    def get_available_tickets(self, event_id: int) -> int:
        pass
    
    @abstractmethod
    def calculate_booking_cost(self, num_tickets: int, ticket_price: float) -> float:
        pass
    
    @abstractmethod
    def book_tickets(self, event_id: int, num_tickets: int, customer_id: int):
        pass
    
    @abstractmethod
    def cancel_booking(self, booking_id: int):
        pass
    
    @abstractmethod
    def get_booking_details(self, booking_id: int):
        pass
