
from dao.ticket_booking_system import TicketBookingSystem


def main():
    system = TicketBookingSystem()
    system.start()


if __name__ == "__main__":
    main()