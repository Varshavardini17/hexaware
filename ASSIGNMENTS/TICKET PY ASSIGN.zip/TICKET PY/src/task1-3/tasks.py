def get_ticket_price(category):
    if category.lower() == "silver":
        return 100
    elif category.lower() == "gold":
        return 200
    elif category.lower() == "diamond":
        return 300
    else:
        return None


def main():
    available_tickets = 50  

    print(" Welcome to Hexaware Ticket Booking System ")

    while True:
        print("\n Ticket Categories:")
        print("1. Silver - ₹100")
        print("2. Gold - ₹200")
        print("3. Diamond - ₹300")
        print("Type 'exit' to quit.\n")

        choice = input("Enter ticket category (Silver/Gold/Diamond) or type 'exit': ").strip()

        if choice.lower() == "exit":
            print(" Thank you for using the booking system")
            break

        price = get_ticket_price(choice)
        if price is None:
            print(" Invalid ticket category. Try again.")
            continue

        try:
            no_of_tickets = int(input("Enter number of tickets you want to book: "))

            if no_of_tickets <= 0:
                print(" Ticket count must be positive.")
                continue

            if available_tickets >= no_of_tickets:
                total_cost = price * no_of_tickets
                available_tickets -= no_of_tickets
                print(f" Booking successful! Total cost: ₹{total_cost}")
                print(f" Remaining tickets: {available_tickets}")
            else:
                print(f" Only {available_tickets} tickets available. Cannot book {no_of_tickets} tickets.")

        except ValueError:
            print(" Invalid input. Please enter a valid number for tickets.")

if __name__ == "__main__":
    main()
