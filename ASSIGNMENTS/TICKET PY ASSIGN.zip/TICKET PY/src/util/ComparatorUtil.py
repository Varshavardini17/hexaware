def sort_events_by_name_and_venue(events):
    return sorted(events, key=lambda e: (e.event_name.lower(), e.venue.venue_name.lower()))