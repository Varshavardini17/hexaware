def remove_duplicates(collection):
    return list(set(collection))