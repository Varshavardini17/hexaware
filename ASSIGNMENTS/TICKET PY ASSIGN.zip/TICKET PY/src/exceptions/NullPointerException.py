class NullPointerException(Exception):
    def __init__(self, message="Null reference encountered"):
        super().__init__(message)