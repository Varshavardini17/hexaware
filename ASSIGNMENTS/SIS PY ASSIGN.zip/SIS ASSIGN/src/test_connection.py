from util.db_conn_util import DBConnUtil


def test_connection():
    conn = DBConnUtil.get_connection()
    if conn:
        print(" Database is connected!")
        conn.close()
    else:
        print(" Failed to connect to the database.")

if __name__ == "__main__":
    test_connection()
