from util.db_conn_util import DBConnUtil
from datetime import datetime

class SISService:
    def __init__(self):
        self.conn = DBConnUtil.get_connection()

    def create_student(self, first_name, last_name, dob, email, phone):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO Student (first_name, last_name, date_of_birth, email, phone_number)
            VALUES (?, ?, ?, ?, ?)
        """, (first_name, last_name, dob, email, phone))
        self.conn.commit()

    def enroll_student(self, student_id, course_ids):
        cursor = self.conn.cursor()
        for course_id in course_ids:
            cursor.execute("""
                INSERT INTO Enrollment (student_id, course_id, enrollment_date)
                VALUES (?, ?, ?)
            """, (student_id, course_id, datetime.now().date()))
        self.conn.commit()

    def assign_teacher(self, first_name, last_name, email, expertise, course_code):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO Teacher (first_name, last_name, email, expertise)
            VALUES (?, ?, ?, ?)
        """, (first_name, last_name, email, expertise))
        teacher_name = f"{first_name} {last_name}"
        cursor.execute("""
            UPDATE Course SET instructor_name = ? WHERE course_code = ?
        """, (teacher_name, course_code))
        self.conn.commit()

    def record_payment(self, student_id, amount, payment_date):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO Payment (student_id, amount, payment_date)
            VALUES (?, ?, ?)
        """, (student_id, amount, payment_date))
        self.conn.commit()

    def generate_enrollment_report(self, course_name):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT s.student_id, s.first_name, s.last_name FROM Enrollment e
            JOIN Student s ON e.student_id = s.student_id
            JOIN Course c ON e.course_id = c.course_id
            WHERE c.course_name = ?
        ''', (course_name,))
        return cursor.fetchall()

    def dynamic_query(self, table, columns='*', condition=None, order_by=None):
        query = f"SELECT {columns} FROM {table}"
        if condition:
            query += f" WHERE {condition}"
        if order_by:
            query += f" ORDER BY {order_by}"
        cursor = self.conn.cursor()
        cursor.execute(query)
        return cursor.fetchall()
