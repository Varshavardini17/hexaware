from exception.sis_exception import *
from entity.model.enrollment import Enrollment
from entity.model.payment import Payment

class SIS:
    def __init__(self):
        self.students = {}
        self.courses = {}
        self.teachers = {}

    def add_student(self, student):
        if not student or not student.student_id:
            raise InvalidStudentDataException("Invalid student data")
        self.students[student.student_id] = student

    def add_course(self, course):
        if not course or not course.course_id:
            raise InvalidCourseDataException("Invalid course data")
        self.courses[course.course_id] = course

    def add_teacher(self, teacher):
        if not teacher or not teacher.teacher_id:
            raise InvalidTeacherDataException("Invalid teacher data")
        self.teachers[teacher.teacher_id] = teacher

    def enroll_student_in_course(self, student_id, course_id, enrollment_date):
        student = self.students.get(student_id)
        course = self.courses.get(course_id)

        if not student:
            raise StudentNotFoundException("Student not found")
        if not course:
            raise CourseNotFoundException("Course not found")

        for e in student.enrollments:
            if e.course.course_id == course_id:
                raise DuplicateEnrollmentException("Student already enrolled")

        enrollment = Enrollment(len(student.enrollments)+1, student, course, enrollment_date)
        student.enrollments.append(enrollment)
        course.enrollments.append(enrollment)

    def assign_course_to_teacher(self, course_id, teacher_id):
        teacher = self.teachers.get(teacher_id)
        course = self.courses.get(course_id)

        if not teacher:
            raise TeacherNotFoundException("Teacher not found")
        if not course:
            raise CourseNotFoundException("Course not found")

        course.assign_teacher(teacher)

    def add_payment(self, student_id, amount, payment_date):
        student = self.students.get(student_id)
        if not student:
            raise StudentNotFoundException("Student not found")
        if amount <= 0:
            raise PaymentValidationException("Invalid payment amount")

        payment = Payment(len(student.payments)+1, student, amount, payment_date)
        student.payments.append(payment)

    def get_enrollments_for_student(self, student_id):
        student = self.students.get(student_id)
        if not student:
            raise StudentNotFoundException("Student not found")
        return student.enrollments

    def get_courses_for_teacher(self, teacher_id):
        teacher = self.teachers.get(teacher_id)
        if not teacher:
            raise TeacherNotFoundException("Teacher not found")
        return teacher.assigned_courses
