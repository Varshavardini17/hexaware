from util.db_conn_util import DBConnUtil

class DBInitService:
    @staticmethod
    def initialize_db():
        conn = DBConnUtil.get_connection()
        cursor = conn.cursor()

        
        cursor.execute('''
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Student' AND xtype='U')
        CREATE TABLE Student (
            student_id INT IDENTITY(1,1) PRIMARY KEY,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            date_of_birth DATE,
            email VARCHAR(150),
            phone_number VARCHAR(20)
        );
        ''')

        cursor.execute('''
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Course' AND xtype='U')
        CREATE TABLE Course (
            course_id INT IDENTITY(1,1) PRIMARY KEY,
            course_name VARCHAR(150),
            course_code VARCHAR(50) UNIQUE,
            instructor_name VARCHAR(150)
        );
        ''')

        cursor.execute('''
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Enrollment' AND xtype='U')
        CREATE TABLE Enrollment (
            enrollment_id INT IDENTITY(1,1) PRIMARY KEY,
            student_id INT,
            course_id INT,
            enrollment_date DATE,
            FOREIGN KEY(student_id) REFERENCES Student(student_id),
            FOREIGN KEY(course_id) REFERENCES Course(course_id)
        );
        ''')

        cursor.execute('''
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Teacher' AND xtype='U')
        CREATE TABLE Teacher (
            teacher_id INT IDENTITY(1,1) PRIMARY KEY,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            email VARCHAR(150),
            expertise VARCHAR(100)
        );
        ''')

        cursor.execute('''
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Payment' AND xtype='U')
        CREATE TABLE Payment (
            payment_id INT IDENTITY(1,1) PRIMARY KEY,
            student_id INT,
            amount FLOAT,
            payment_date DATE,
            FOREIGN KEY(student_id) REFERENCES Student(student_id)
        );
        ''')

        conn.commit()
        conn.close()
