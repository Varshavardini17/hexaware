class Course:
    def __init__(self, course_id, name, code, instructor_name=None):
        self.course_id = course_id
        self.course_name = name
        self.course_code = code
        self.instructor_name = instructor_name
        self.enrollments = []
        self.teacher = None

    def assign_teacher(self, teacher):
        self.teacher = teacher
        teacher.assigned_courses.append(self)

    def update_course_info(self, code, name, instructor):
        self.course_code = code
        self.course_name = name
        self.instructor_name = instructor

    def display_course_info(self):
        print(f"ID: {self.course_id}, Name: {self.course_name}, Code: {self.course_code}, Instructor: {self.instructor_name}")

    def get_enrollments(self):
        return self.enrollments

    def get_teacher(self):
        return self.teacher
