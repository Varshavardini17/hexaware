
from dao.DB_Init_Service import DBInitService
from dao.SIS_Service import SISService

def main():
    DBInitService.initialize_db()
    sis = SISService()

    
    sis.create_student("John", "Doe", "1995-08-15", "john.doe@example.com", "123-456-7890")
    john_id = sis.conn.execute("SELECT student_id FROM Student WHERE email = ?", ("john.doe@example.com",)).fetchone()[0]

    try:
        sis.conn.execute("INSERT INTO Course (course_name, course_code) VALUES (?, ?)", ("Introduction to Programming", "CS101"))
        sis.conn.commit()
        print("Course inserted successfully.")
    except:
        print("Course already exists or other integrity error:")

    sis.conn.execute("INSERT INTO Course (course_name, course_code) VALUES (?, ?)", ("Mathematics 101", "MATH101"))
    sis.conn.commit()

    courses = sis.conn.execute("SELECT course_id FROM Course WHERE course_code IN (?, ?)", ("CS101", "MATH101")).fetchall()
    course_ids = [row[0] for row in courses]
    sis.enroll_student(john_id, course_ids)

    print("Task 9: Assign Sarah Smith to CS302")
    sis.conn.execute("INSERT INTO Course (course_name, course_code) VALUES (?, ?)",
                        ("Advanced Database Management", "CS302"))
    sis.assign_teacher("Sarah", "Smith", "sarah.smith@example.com", "Computer Science", "CS302")

    print("Task 10: Payment by Jane Johnson")
    sis.create_student("Jane", "Johnson", "1998-11-22", "jane.johnson@example.com", "321-654-0987")
    jane_id = sis.conn.execute("SELECT student_id FROM Student WHERE email = ?", ("jane.johnson@example.com",)).fetchone()[0]
    sis.record_payment(jane_id, 500.00, "2023-04-10")

    print(" Task 11: Generate Enrollment Report for Computer Science 101")
    sis.conn.execute("INSERT INTO Course (course_name, course_code) VALUES (?, ?)",
                        ("Computer Science 101", "CS103"))
    course_id = sis.conn.execute("SELECT course_id FROM Course WHERE course_code = 'CS103'").fetchone()[0]
    sis.enroll_student(jane_id, [course_id])
    report = sis.generate_enrollment_report("Computer Science 101")
    print("\nEnrollment Report for Computer Science 101:")
    for row in report:
        print("Student ID:", row[0], "Name:", row[1], row[2])

if __name__ == '__main__':
    main()
