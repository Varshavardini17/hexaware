import pyodbc

class DBConnUtil:
    @staticmethod
    def get_connection():
        try:
            conn = pyodbc.connect(
    'DRIVER={ODBC Driver 17 for SQL Server};'
    'SERVER=DESKTOP112\MSSQLSERVER02;'  
    'DATABASE=StudentInfo;'  
    'Trusted_Connection=yes;'  
)


            print(" Connected to the database successfully.")
            return conn
        except Exception as e:
            print(" Database connection error:", e)
            return None
