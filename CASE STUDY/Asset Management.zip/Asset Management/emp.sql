

-- Users Table
CREATE TABLE Users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    created_at DATETIME NOT NULL DEFAULT GETDATE(),
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL
);

-- Employees Table
CREATE TABLE Employees (
    employee_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    joining_date DATE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(50),
    status VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- Assets Table
CREATE TABLE Assets (
    asset_id INT IDENTITY(1,1) PRIMARY KEY,
    purchase_date DATE,
    asset_name VARCHAR(100) NOT NULL,
    asset_type VARCHAR(50),
    cost DECIMAL(10,2),
    status VARCHAR(20)
);

-- Maintenance Requests Table
CREATE TABLE Maintenance_Requests (
    request_id INT IDENTITY(1,1) PRIMARY KEY,
    asset_id INT NOT NULL,
    employee_id INT NOT NULL,
    issue_description TEXT,
    request_date DATETIME DEFAULT GETDATE(),
    status VARCHAR(20),
    FOREIGN KEY (asset_id) REFERENCES Assets(asset_id),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Asset Assignments Table
CREATE TABLE Asset_Assignments (
    assignment_id INT IDENTITY(1,1) PRIMARY KEY,
    asset_id INT NOT NULL,
    employee_id INT NOT NULL,
    assigned_date DATETIME DEFAULT GETDATE(),
    return_date DATETIME,
    status VARCHAR(20),
    FOREIGN KEY (asset_id) REFERENCES Assets(asset_id),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Asset Requests Table
CREATE TABLE Asset_Requests (
    request_id INT IDENTITY(1,1) PRIMARY KEY,
    employee_id INT NOT NULL,
    request_reason TEXT,
    request_date DATETIME DEFAULT GETDATE(),
    asset_type VARCHAR(50),
    status VARCHAR(20),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);
select * from Users;
select * from Employees;
select * from Maintenance_Requests;
select * from Asset_Assignments;
select * from Asset_Requests;

