class AssetNotMaintainException(Exception):
    def __init__(self, message="Asset has not been maintained for over 2 years."):
        super().__init__(message)
